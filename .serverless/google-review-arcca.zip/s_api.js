
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'juanfariasdev',
  applicationName: 'google-review-arcca',
  appUid: 'FTWQBs24QH1qchBstN',
  orgUid: '473f59df-90d0-46ab-9c6e-cf096af32880',
  deploymentUid: '954c602c-c428-4bad-8014-7292cd60a442',
  serviceName: 'google-review-arcca',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'google-review-arcca-dev-api', timeout: 15 };

try {
  const userHandler = require('./dist/lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}